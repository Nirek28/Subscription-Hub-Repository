import { validateCancelUrl } from './domain.js';

// Cancellation pages for large services. These are kept on the server only and are never sent to the
// browser or listed in the interface. Providers move these pages, so review them every few months.
const KNOWN_SERVICES = [
  { match: ['netflix'], url: 'https://www.netflix.com/cancelplan' },
  { match: ['youtube premium', 'youtube music'], url: 'https://www.youtube.com/paid_memberships' },
  { match: ['spotify'], url: 'https://www.spotify.com/account/subscription/' },
  { match: ['amazon prime', 'prime video', 'primevideo'], url: 'https://www.amazon.in/gp/primecentral' },
  { match: ['canva'], url: 'https://www.canva.com/settings/billing' },
  { match: ['chatgpt', 'chat gpt', 'openai'], url: 'https://chatgpt.com/#settings' },
  { match: ['microsoft 365', 'office 365', 'onedrive'], url: 'https://account.microsoft.com/services/' },
  { match: ['adobe'], url: 'https://account.adobe.com/plans' }
];

const normalise = (...parts) => parts.filter(Boolean).join(' ').toLowerCase();

export function knownCancelUrl({ name = '', merchant = '' } = {}) {
  const text = normalise(name, merchant);
  return KNOWN_SERVICES.find((service) => service.match.some((word) => text.includes(word)))?.url || '';
}

export const isKnownService = (details) => !!knownCancelUrl(details);

// Known services always use our verified page. Other services use the link the user supplied.
export function resolveCancelUrl(sub = {}) {
  return knownCancelUrl(sub) || validateCancelUrl(sub.cancelUrl);
}
