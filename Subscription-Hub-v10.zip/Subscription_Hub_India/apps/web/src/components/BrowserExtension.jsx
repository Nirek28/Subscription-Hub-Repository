import React, { useEffect, useState } from 'react';

const selectStyle = { background: '#16181f', color: '#eef1f6', border: '1px solid #2e323c', borderRadius: 8, padding: '9px 12px', minWidth: 220, fontSize: 13, colorScheme: 'dark' };

export default function BrowserExtension({ request }) {
  const [data, setData] = useState(null);
  const [assign, setAssign] = useState({});
  const [code, setCode] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  async function load() {
    const value = await request('/extension/settings');
    setData(value);
    setAssign(Object.fromEntries(value.mappings.map((m) => [m.subscriptionId, m.key])));
  }

  // Devices refresh automatically. Unsaved website choices are left alone.
  async function refreshDevices() {
    try {
      const value = await request('/extension/settings');
      setData((current) => (current ? { ...current, devices: value.devices, subscriptions: value.subscriptions, mappings: value.mappings } : value));
    } catch { /* keep the last known state */ }
  }

  useEffect(() => {
    load().catch((e) => setMessage(e.message));
    const timer = setInterval(refreshDevices, 30000);
    return () => clearInterval(timer);
  }, []);

  async function act(fn) {
    setBusy(true); setMessage('');
    try { await fn(); } catch (e) { setMessage(e.message); } finally { setBusy(false); }
  }

  const lastUpload = (value) => (value ? new Date(value).toLocaleString() : 'Waiting for first upload');
  // Only subscriptions the user opted into browser tracking are listed here.
  const subscriptions = data?.subscriptions || [];
  const activeIds = new Set(subscriptions.map((s) => s.id));
  const siteTakenByOther = (siteKey, subscriptionId) =>
    Object.entries(assign).some(([id, key]) => key === siteKey && id !== subscriptionId && activeIds.has(id));

  async function saveWebsites() {
    const mappings = Object.entries(assign)
      .filter(([id, key]) => key && activeIds.has(id))
      .map(([subscriptionId, key]) => ({ key, subscriptionId }));
    await request('/extension/settings', { method: 'PUT', body: JSON.stringify({ mappings }) });
    await load();
    setMessage('Saved. The extension picks up this change within a minute.');
  }

  return (
    <article className="panel settings-card extension-settings">
      <div className="panel-heading">
        <div><h2>Connect your browser</h2><p className="muted">Set up automatic time tracking for the services you chose to track.</p></div>
        {data && data.devices.length > 0 && <span className="settings-badge safe">Auto-sync on</span>}
      </div>

      <div className="ext-steps">
        <div><b>1</b><span>Load the extension once: Chrome → Extensions → Developer mode → Load unpacked → select the <code>extension</code> folder.</span></div>
        <div><b>2</b><span>For each tracked subscription, choose the website where you use it, then save.</span></div>
        <div><b>3</b><span>Generate a code, paste it in the extension, then press Start tracking.</span></div>
      </div>

      {message && <p role="status" className="ext-message">{message}</p>}

      {!data ? <p className="muted">Loading…</p> : <>
        <h3>Tracked subscriptions</h3>
        {!subscriptions.length && <p className="muted">No subscriptions are set up for browser tracking yet.</p>}
        {subscriptions.map((sub) => (
          <div className="settings-row" key={sub.id}>
            <div><b>{sub.name}</b><small>Choose the website you use this service on</small></div>
            <select aria-label={`Website for ${sub.name}`} style={selectStyle} value={assign[sub.id] || ''} onChange={(e) => setAssign({ ...assign, [sub.id]: e.target.value })}>
              <option value="">Not on a tracked website</option>
              {data.catalog.map((site) => (
                <option key={site.key} value={site.key} disabled={siteTakenByOther(site.key, sub.id)}>
                  {site.name}{siteTakenByOther(site.key, sub.id) ? ' (used by another subscription)' : ''}
                </option>
              ))}
            </select>
          </div>
        ))}
        {subscriptions.length > 0 && <button className="primary ext-save" disabled={busy} onClick={() => act(saveWebsites)}>Save websites</button>}

        <h3>Connection code</h3>
        <p className="muted">Codes expire after five minutes and work once. A connected browser stays linked for 30 days.</p>
        <button className="secondary" disabled={busy} onClick={() => act(async () => setCode(await request('/extension/pairing-code', { method: 'POST', body: '{}' })))}>Generate connection code</button>
        {code && <div className="extension-code">
          <label>Paste this code into the extension<input readOnly value={code.code} onFocus={(e) => e.target.select()} /></label>
          <small>Expires {new Date(code.expiresAt).toLocaleTimeString()}</small>
        </div>}

        <h3>Connected browsers</h3>
        {!data.devices.length && <p className="muted">No connected browsers yet.</p>}
        {data.devices.map((d) => (
          <div className="settings-row" key={d.id}>
            <div><b>{d.name}</b><small>Last upload: {lastUpload(d.lastSync)} · {d.expiresAt < Date.now() ? 'Expired' : 'Expires ' + new Date(d.expiresAt).toLocaleDateString()}</small></div>
            <button className="secondary" disabled={busy} onClick={() => act(async () => { await request('/extension/devices/' + d.id, { method: 'DELETE', body: '{}' }); await load(); })}>Disconnect</button>
          </div>
        ))}

        <h3>Your data</h3>
        <p className="muted">Only subscription IDs, times and durations are uploaded. No page content, titles, passwords or full browsing history.</p>
        <button className="secondary" disabled={busy} onClick={() => {
          if (window.confirm('Delete all extension-tracked history and disconnect all browsers? Manual logs remain.')) {
            act(async () => { await request('/extension/history', { method: 'DELETE', body: '{}' }); await load(); setMessage('Extension history deleted. Reconnect a browser to resume tracking.'); });
          }
        }}>Delete extension history and disconnect</button>
      </>}
    </article>
  );
}
