import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, useLocation, useNavigate } from 'react-router-dom';
import BrowserExtension from './components/BrowserExtension.jsx';
import SubscriptionManager from './components/SubscriptionManager.jsx';
import { apiFetch } from './api.js';
import './styles.css';
import './nocturne.css';

const request = apiFetch;
const emptyAnalytics = { monthlySpend: 0, activeCount: 0, canceledCount: 0, bySubscription: [], insights: [] };
const money = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(value || 0));
const daysUntil = (date) => Math.ceil((new Date(date) - Date.now()) / 86400000);
const todayLabel = () => new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).format(new Date()).toUpperCase();
const initial = (name = '') => name.slice(0, 1).toUpperCase() || '•';

// Navigation. Analytics, Settings and Browser tracking appear only after the user has subscriptions.
const PAGES = {
  Home: { path: '/', title: 'Home' },
  Subscriptions: { path: '/subscriptions', title: 'Subscriptions' },
  Analytics: { path: '/analytics', title: 'Analytics' },
  'Browser tracking': { path: '/tracking', title: 'Browser tracking' },
  Settings: { path: '/settings', title: 'Settings' }
};
const pathToPage = Object.fromEntries(Object.entries(PAGES).map(([name, page]) => [page.path, name]));

function AuthScreen({ onAuthenticated }) {
  const navigate = useNavigate();
  const [mode, setMode] = useState(() => (window.location.pathname === '/reset-password' ? 'reset-password' : window.location.pathname === '/verify-email' ? 'verify-email' : 'login'));
  const [token] = useState(() => new URLSearchParams(window.location.hash.slice(1)).get('token') || '');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (window.location.hash) window.history.replaceState(null, '', window.location.pathname); }, []);
  const titles = { register: 'Create your account', login: 'Welcome back', 'forgot-password': 'Reset your password', 'reset-password': 'Choose a new password', 'verify-email': 'Verify your email', 'resend-verification': 'Resend verification' };
  const emailOnly = ['forgot-password', 'resend-verification'].includes(mode);
  const passwordMode = ['register', 'login', 'reset-password'].includes(mode);
  const newPassword = ['register', 'reset-password'].includes(mode);
  const switchMode = (next) => { setMode(next); setPassword(''); setConfirmPassword(''); setError(''); setNotice(''); navigate('/', { replace: true }); };

  const submit = async (event) => {
    event.preventDefault(); setError(''); setNotice('');
    if (newPassword && password !== confirmPassword) { setError('The passwords do not match.'); return; }
    setBusy(true);
    try {
      const result = await request(`/api/auth/${mode}`, { method: 'POST', body: JSON.stringify({ name, email, password, token }) });
      if (mode === 'login') onAuthenticated(result.user);
      else {
        if (!emailOnly) { setMode('login'); setPassword(''); setConfirmPassword(''); navigate('/', { replace: true }); }
        setNotice(result.message);
      }
    } catch (e) {
      setError(e.message === 'Failed to fetch' ? 'Cannot reach the app. Make sure start.bat is still running.' : e.message);
    } finally { setBusy(false); }
  };

  return <main className="auth-shell">
    <section className="auth-visual">
      <div className="brand"><span className="brand-mark">S</span><span>Subscription Hub</span></div>
      <div className="auth-visual-copy">
        <span className="eyebrow">YOUR RECURRING SPEND</span>
        <h1>Stay in control<br /><em>of every renewal.</em></h1>
        <p>Track renewals, see what you actually use, and cancel the services you no longer need.</p>
      </div>
      <div className="auth-visual-foot">Built for India · INR subscriptions</div>
    </section>
    <section className="auth-form-side"><div className="auth-card">
      <span className="eyebrow">{mode === 'register' ? 'GET STARTED' : 'SIGN IN'}</span>
      <h2>{titles[mode]}</h2>
      <p className="auth-subtitle">{emailOnly ? 'Enter your account email to receive a secure link.' : mode === 'verify-email' ? 'Confirm your email. Links expire after 24 hours.' : mode === 'reset-password' ? 'Choose a password of 8–128 characters.' : 'Sign in to your private workspace.'}</p>
      {notice && <div className="auth-notice" role="status">{notice}</div>}
      {error && <div className="auth-error" role="alert">{error}</div>}
      <form onSubmit={submit}>
        {mode === 'register' && <label className="auth-field">Full name<input autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" required minLength={2} maxLength={100} /></label>}
        {!['reset-password', 'verify-email'].includes(mode) && <label className="auth-field">Email address<input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required /></label>}
        {passwordMode && <label className="auth-field">Password<input type="password" autoComplete={newPassword ? 'new-password' : 'current-password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === 'register' ? 'At least 8 characters' : 'Your password'} required minLength={newPassword ? 8 : undefined} maxLength={128} /></label>}
        {newPassword && <label className="auth-field">Confirm password<input type="password" autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Enter your password again" required minLength={8} maxLength={128} /></label>}
        <button className="primary auth-submit" type="submit" disabled={busy}>{busy ? 'Please wait…' : emailOnly ? 'Send link' : mode === 'reset-password' ? 'Save password' : mode === 'verify-email' ? 'Verify email' : mode === 'register' ? 'Create account' : 'Sign in'}</button>
      </form>
      <div className="auth-switch"><button type="button" disabled={busy} onClick={() => switchMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Create an account' : 'Back to sign in'}</button></div>
      <div className="auth-switch"><button type="button" disabled={busy} onClick={() => switchMode('forgot-password')}>Forgot password?</button> · <button type="button" disabled={busy} onClick={() => switchMode('resend-verification')}>Resend verification</button></div>
    </div></section>
  </main>;
}

function SubscriptionForm({ onClose, onSave }) {
  const [form, setForm] = useState({ name: '', merchant: '', category: 'Other', monthlyCost: '', renewalDate: '', cancelUrl: '', trackingOptIn: false });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const change = (field) => (event) => setForm((current) => ({ ...current, [field]: event.target.type === 'checkbox' ? event.target.checked : event.target.value }));
  const submit = async (event) => {
    event.preventDefault(); setBusy(true); setError('');
    try { await onSave({ ...form, monthlyCost: Number(form.monthlyCost), currency: 'INR' }); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };
  return <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}><div className="modal entry-modal">
    <button className="modal-close" onClick={onClose} aria-label="Close">×</button>
    <div className="eyebrow">NEW SUBSCRIPTION</div>
    <h2>Add a subscription</h2>
    <p>Enter the details from your plan. Amounts are in INR.</p>
    {error && <div className="auth-error" role="alert">{error}</div>}
    <form className="entry-form" onSubmit={submit}>
      <label>Subscription name<input value={form.name} onChange={change('name')} placeholder="e.g. Premium plan" maxLength={100} required /></label>
      <label>Service / provider<input value={form.merchant} onChange={change('merchant')} placeholder="e.g. Netflix" maxLength={100} required /></label>
      <label>Category<select value={form.category} onChange={change('category')}><option>Other</option><option>Entertainment</option><option>Music</option><option>Productivity</option><option>Lifestyle</option><option>Utilities</option></select></label>
      <label>Monthly cost (₹)<input type="number" min="0" step="0.01" value={form.monthlyCost} onChange={change('monthlyCost')} placeholder="0.00" required /></label>
      <label>Next renewal date<input type="date" value={form.renewalDate} onChange={change('renewalDate')} required /></label>
      <label>Cancellation page link<input type="url" value={form.cancelUrl} onChange={change('cancelUrl')} placeholder="https://provider.com/account" /><small className="field-hint">Only needed if we don't already know this service. Stored privately and never shown.</small></label>
      <label className="check-row"><input type="checkbox" checked={form.trackingOptIn} onChange={change('trackingOptIn')} /><span>Track my time on this service in my browser (uses the browser extension)</span></label>
      <div className="entry-actions"><button type="button" className="secondary" onClick={onClose}>Cancel</button><button className="primary" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save subscription'}</button></div>
    </form>
  </div></div>;
}

function UsageForm({ subscriptions, onClose, onSave }) {
  const firstActive = subscriptions[0];
  const [subscriptionId, setSubscriptionId] = useState(firstActive?.id || '');
  const [hours, setHours] = useState('');
  const [cost, setCost] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submit = async (event) => {
    event.preventDefault(); setBusy(true); setError('');
    try { await onSave({ subscriptionId, source: 'manual', hours: Number(hours), cost: Number(cost) }); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };
  return <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}><div className="modal entry-modal">
    <button className="modal-close" onClick={onClose} aria-label="Close">×</button>
    <div className="eyebrow">MANUAL TRACKING</div>
    <h2>Log subscription usage</h2>
    <p>Record hours used and the amount for that period.</p>
    {error && <div className="auth-error" role="alert">{error}</div>}
    {!subscriptions.length ? <div className="empty">Add a subscription before logging usage.</div> : <form className="entry-form" onSubmit={submit}>
      <label>Subscription<select value={subscriptionId} onChange={(e) => setSubscriptionId(e.target.value)} required>{subscriptions.map((sub) => <option key={sub.id} value={sub.id}>{sub.name}</option>)}</select></label>
      <label>Hours used<input type="number" min="0" step="0.1" value={hours} onChange={(e) => setHours(e.target.value)} placeholder="e.g. 5" required /></label>
      <label>Cost incurred (₹)<input type="number" min="0" step="0.01" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="e.g. 199" required /></label>
      <div className="entry-actions"><button type="button" className="secondary" onClick={onClose}>Cancel</button><button className="primary" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save usage'}</button></div>
    </form>}
  </div></div>;
}

function SubscriptionsPage({ subs, onAutoCancel, onAdd, onImported }) {
  const [query, setQuery] = useState('');
  const filtered = subs.filter((sub) => `${sub.name} ${sub.merchant} ${sub.category} ${sub.status}`.toLowerCase().includes(query.toLowerCase()));
  const active = subs.filter((sub) => sub.status === 'active');
  const monthly = active.reduce((sum, sub) => sum + Number(sub.monthlyCost || 0), 0);
  return <>
    <div className="page-summary-grid">
      <article className="panel summary-tile"><span>All subscriptions</span><b>{subs.length}</b><small>Tracked services</small></article>
      <article className="panel summary-tile"><span>Active</span><b>{active.length}</b><small>Currently monitored</small></article>
      <article className="panel summary-tile"><span>Canceled</span><b>{subs.length - active.length}</b><small>In this workspace</small></article>
      <article className="panel summary-tile"><span>Monthly total</span><b>{money(monthly)}</b><small>Active subscriptions</small></article>
    </div>
    <div style={{ marginBottom: 20 }}><SubscriptionManager onImported={onImported} /></div>
    <article className="panel full-list-panel">
      <div className="panel-heading">
        <div><h2>Your subscriptions</h2><p className="muted">Review billing dates, costs and cancellation.</p></div>
        <div className="list-actions"><button className="primary" onClick={onAdd}>＋ Add subscription</button></div>
      </div>
      <div className="list-toolbar"><label className="search-box"><span>⌕</span><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search subscriptions" aria-label="Search subscriptions" /></label><span className="result-count">{filtered.length} result{filtered.length === 1 ? '' : 's'}</span></div>
      <div className="table-head"><span>SUBSCRIPTION</span><span>MONTHLY COST</span><span>NEXT BILLING</span><span>STATUS</span><span>ACTIONS</span></div>
      {filtered.map((sub) => <div className="sub-row" key={sub.id}>
        <div className="service"><div className="service-icon">{initial(sub.name)}</div><div><b>{sub.name}</b><small>{sub.category} · {sub.merchant}{sub.trackingOptIn ? ' · browser tracking on' : ''}</small></div></div>
        <div className="cost">{money(sub.monthlyCost)}<small>/month</small></div>
        <div className="billing"><b>{new Date(sub.renewalDate).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}</b><small>{sub.status === 'active' ? `in ${Math.max(0, daysUntil(sub.renewalDate))} days` : 'No upcoming charge'}</small></div>
        <div><span className={`status ${sub.status}`}>{`● ${sub.status}`}</span></div>
        <div className="row-actions">{sub.status === 'active' && <button className="cancel-link" onClick={() => onAutoCancel(sub)}>Auto cancel</button>}</div>
      </div>)}
      {!filtered.length && <div className="empty">{subs.length ? 'No subscriptions match that search.' : 'No subscriptions yet. Add your first one to get started.'}</div>}
    </article>
  </>;
}

function AiInsightsPanel({ subscriptions, onChanged, usageKey }) {
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const load = async (refresh = false) => {
    setBusy(true); setError('');
    try { setData(await request(`/analytics/ai-insights${refresh ? '?refresh=1' : ''}`)); }
    catch (e) { setError(e.message || 'Could not load insights.'); }
    finally { setBusy(false); }
  };
  useEffect(() => { load(false); }, [subscriptions.length, usageKey]);
  const setMultiplier = async (id, value) => {
    try {
      await request(`/subscriptions/${id}/ux-multiplier`, { method: 'POST', body: JSON.stringify({ multiplier: Number(value) }) });
      if (onChanged) await onChanged();
      await load(false);
    } catch (e) { setError(e.message || 'Could not save the estimate.'); }
  };
  const rows = data?.rows || [];
  const insights = data?.insights || [];
  return <article className="panel">
    <div className="panel-heading">
      <div><h2>AI insights</h2><p className="muted">Services that cost more than they're worth to you{data ? ` · ${data.source === 'gemini' ? 'written by Gemini' : 'rule-based'}` : ''}</p></div>
      <button className="secondary" onClick={() => load(true)} disabled={busy}>{busy ? 'Analysing…' : 'Refresh'}</button>
    </div>
    {error && <div className="empty">{error}</div>}
    {data?.warning && <div className="insight-disclaimer">{data.warning}</div>}
    {insights.map((item, i) => <div className="review-item" key={i}><div><b>{item.title}</b><p>{item.detail}</p></div><strong>{item.estimatedMonthlySaving ? `Save up to ${money(item.estimatedMonthlySaving)}` : item.type}</strong></div>)}
    {data && !insights.length && !error && <div className="empty">{rows.length ? 'No redundant or inefficient subscriptions found.' : 'Log usage to see insights.'}</div>}
    {rows.length > 0 && <div className="usage-rows">
      <p className="muted">Effective cost per hour = monthly cost ÷ (tracked hours × your multiplier for phone and TV use).</p>
      {rows.map((row) => <div className="usage-row" key={row.subscriptionId}>
        <b>{row.name}</b>
        <span>{Number(row.trackedHours).toFixed(1)} h</span>
        <select value={row.uxMultiplier} onChange={(e) => setMultiplier(row.subscriptionId, e.target.value)}>
          {[1, 1.25, 1.5, 2, 3].map((v) => <option key={v} value={v}>{v === 1 ? '×1 (desktop only)' : `×${v}`}</option>)}
        </select>
        <span>{row.effectiveCostPerHour == null ? 'No usage yet' : `${money(row.effectiveCostPerHour)} / hr`}</span>
      </div>)}
    </div>}
  </article>;
}

function AnalyticsPage({ analytics, subscriptions, onLogUsage, onChanged }) {
  const rows = analytics.bySubscription || [];
  const trackedHours = rows.reduce((sum, row) => sum + Number(row.hoursThisMonth || 0), 0);
  const costPerHour = trackedHours ? Number(analytics.monthlySpend || 0) / trackedHours : 0;
  const maxCost = Math.max(1, ...rows.map((row) => Number(row.monthlyCost || 0)));
  const usageKey = JSON.stringify(rows.map((row) => [row.subscriptionId, row.hoursThisMonth]));
  return <>
    <div className="page-summary-grid">
      <article className="panel summary-tile"><span>Monthly recurring spend</span><b>{money(analytics.monthlySpend)}</b><small>Active services only</small></article>
      <article className="panel summary-tile"><span>Tracked usage</span><b>{trackedHours.toFixed(1)} hrs</b><small>Across listed services</small></article>
      <article className="panel summary-tile"><span>Average cost per hour</span><b>{costPerHour ? money(costPerHour) : '—'}</b><small>Spend divided by tracked hours</small></article>
      <article className="panel summary-tile"><span>Subscriptions</span><b>{analytics.activeCount || 0}</b><small>Active right now</small></article>
    </div>
    <div className="dashboard-grid">
      <article className="panel analytics-chart-panel">
        <div className="panel-heading"><div><h2>Cost and usage</h2><p className="muted">Monthly cost against tracked hours.</p></div><button className="secondary" onClick={onLogUsage} disabled={!subscriptions.length}>＋ Log usage</button></div>
        <div className="analytics-bars">{rows.map((row) => <div className="analytics-bar-row" key={row.subscriptionId}>
          <div className="analytics-bar-label"><b>{row.name}</b><small>{Number(row.hoursThisMonth || 0).toFixed(2)} hrs ({Number(row.browserHours || 0).toFixed(2)} browser / {Number(row.manualHours || 0).toFixed(2)} manual) · {row.costPerHour == null ? 'No usage data' : `${money(row.costPerHour)} / hr`}</small></div>
          <div className="analytics-bar-track"><i className="analytics-cost-fill" style={{ width: `${Math.max(3, Number(row.monthlyCost || 0) / maxCost * 100)}%` }} /></div>
          <b className="analytics-value">{money(row.monthlyCost)}</b>
        </div>)}{!rows.length && <div className="empty">Usage and cost details will appear here.</div>}</div>
      </article>
      <article className="panel insights-panel">
        <div className="panel-heading"><div><h2>Low usage</h2><p className="muted">Services with under five tracked hours.</p></div></div>
        {rows.filter((row) => Number(row.hoursThisMonth || 0) < 5).sort((a, b) => Number(b.monthlyCost || 0) - Number(a.monthlyCost || 0)).map((row) => <div className="review-item" key={row.subscriptionId}><div><b>{row.name}</b><p>{Number(row.hoursThisMonth || 0).toFixed(1)} hours tracked against {money(row.monthlyCost)} a month.</p></div><strong>{row.hoursThisMonth === 0 ? 'No tracked data' : 'Low use'}</strong></div>)}
        <div className="insight-disclaimer">No tracked data does not always mean no use. Tracking covers only what you have turned on.</div>
      </article>
    </div>
    <div className="analytics-extra"><AiInsightsPanel subscriptions={subscriptions} onChanged={onChanged} usageKey={usageKey} /></div>
  </>;
}

function BrowserTrackingPage() {
  return <div className="settings-page">
    <div className="tracking-intro">
      <span className="eyebrow">BROWSER TRACKING</span>
      <p className="muted">Time spent on services you chose to track is measured by the browser extension and added to your analytics automatically. Phone and TV use is not included.</p>
    </div>
    <BrowserExtension request={request} />
  </div>;
}

function SettingsPage() {
  const [status, setStatus] = useState(null);
  useEffect(() => { request('/india/status').then(setStatus).catch(() => {}); }, []);
  const integrations = [
    ['Setu AA', 'Consented bank-data discovery', status?.setu?.configured ? status.setu.mode + ' configured' : 'Not configured'],
    ['Razorpay', 'UPI AutoPay and recurring billing', status?.razorpay?.configured ? status.razorpay.mode + ' configured' : 'Not configured'],
    ['CSV import', 'Indian debit transaction detection', 'Available'],
    ['Gemini', 'Optional usage insights', status?.gemini ? 'Configured' : 'Local rules'],
    ['SendGrid', 'Renewal email', status?.email ? 'Configured' : 'Preview only']
  ];
  return <div className="settings-page">
    <article className="panel settings-card"><div className="panel-heading"><div><h2>Preferences</h2><p className="muted">Display and privacy.</p></div></div>
      <div className="settings-row"><div><b>Display currency</b><small>Amounts are shown in Indian Rupees.</small></div><span className="settings-badge">INR · ₹</span></div>
      <div className="settings-row"><div><b>Privacy</b><small>Bank and payment authorisation happen on provider screens.</small></div><span className="settings-badge safe">Provider-hosted</span></div>
    </article>
    <article className="panel settings-card"><div className="panel-heading"><div><h2>Integrations</h2><p className="muted">Provider connections.</p></div></div>
      {integrations.map(([name, purpose, state]) => <div className="settings-row integration-row" key={name}><div><b>{name}</b><small>{purpose}</small></div><span className="integration-status"><i />{state}</span></div>)}
    </article>
  </div>;
}

function HomePage({ subs, analytics, activeSubs, user, onAdd, onExplore }) {
  const next = [...activeSubs].sort((a, b) => new Date(a.renewalDate) - new Date(b.renewalDate));
  const first = user?.name?.split(' ')[0] || 'there';
  return <>
    <section className="hero-full" style={{ backgroundImage: "url(/hero-night.svg)" }}>
      <div className="hero-headline">
        <span className="eyebrow">{todayLabel()}</span>
        <h1>Stay on top<br /><em>of every renewal.</em></h1>
        <p>Good to see you, {first}. See what you pay each month, what you use, and cancel what you no longer need.</p>
      </div>
      <div className="hero-bar">
        <div className="bar-cell"><span>Monthly spend</span><b>{money(analytics.monthlySpend)}</b></div>
        <div className="bar-cell"><span>Active</span><b>{analytics.activeCount || 0}</b></div>
        <div className="bar-cell"><span>Next renewal</span><b>{next.length ? `${Math.max(0, daysUntil(next[0].renewalDate))} days` : '—'}</b></div>
        <button className="bar-cta" onClick={onAdd}>Add subscription</button>
      </div>
    </section>
    {!!next.length && <article className="panel upcoming-panel">
      <div className="panel-heading"><div><h2>Upcoming renewals</h2><p className="muted">The next charges on your calendar</p></div></div>
      {next.slice(0, 4).map((sub) => <div className="renewal-row" key={sub.id}>
        <div className="date-tile"><b>{new Date(sub.renewalDate).getDate()}</b><small>{new Date(sub.renewalDate).toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}</small></div>
        <div className="renewal-name"><b>{sub.name}</b><small>{daysUntil(sub.renewalDate) <= 3 ? 'Coming up soon' : 'Auto-renewal'}</small></div>
        <b className="renewal-cost">{money(sub.monthlyCost)}</b>
      </div>)}
    </article>}
    {!subs.length && <section className="empty-start panel"><div><h2>Start with your first subscription</h2><p>Add a service, its monthly cost and renewal date. Analytics and browser tracking unlock after you add one.</p><button className="primary" onClick={onAdd}>Add your first subscription →</button></div></section>}
  </>;
}

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const [subs, setSubs] = useState([]);
  const [analytics, setAnalytics] = useState(emptyAnalytics);
  const [loaded, setLoaded] = useState(false);
  const [modal, setModal] = useState(false);
  const [usageModal, setUsageModal] = useState(false);
  const [notice, setNotice] = useState('');
  const [selected, setSelected] = useState(null);
  const [notificationModal, setNotificationModal] = useState(false);
  const [notificationItems, setNotificationItems] = useState([]);
  const [notificationError, setNotificationError] = useState('');
  const [notificationBusy, setNotificationBusy] = useState(false);
  const [updatedAt, setUpdatedAt] = useState(null);
  const [live, setLive] = useState(false);
  const [user, setUser] = useState(null);
  const [authChecking, setAuthChecking] = useState(true);

  const refresh = async () => {
    try {
      const [s, a] = await Promise.all([request('/subscriptions'), request('/analytics')]);
      setSubs(s); setAnalytics(a); setLive(true); setUpdatedAt(new Date());
    } catch { setLive(false); }
    finally { setLoaded(true); }
  };

  useEffect(() => {
    let active = true;
    request('/api/auth/me').then((result) => { if (active) setUser(result.user); }).catch(() => {}).finally(() => { if (active) setAuthChecking(false); });
    return () => { active = false; };
  }, []);
  useEffect(() => { if (user) refresh(); }, [user]);
  // Browser usage uploaded by the extension appears here without a reload.
  useEffect(() => {
    if (!user) return undefined;
    const tick = () => { if (!document.hidden) refresh(); };
    const timer = setInterval(tick, 30000);
    window.addEventListener('focus', tick);
    document.addEventListener('visibilitychange', tick);
    return () => { clearInterval(timer); window.removeEventListener('focus', tick); document.removeEventListener('visibilitychange', tick); };
  }, [user]);

  const activeSubs = useMemo(() => subs.filter((s) => s.status === 'active'), [subs]);
  const hasSubs = subs.length > 0;
  const hasTracking = activeSubs.some((s) => s.trackingOptIn);
  const visiblePages = Object.keys(PAGES).filter((name) => {
    if (name === 'Home' || name === 'Subscriptions') return true;
    if (name === 'Browser tracking') return hasTracking;
    return hasSubs;
  });
  const activeTab = pathToPage[location.pathname] || 'Home';

  // Hidden pages cannot be reached by typing their address before the first subscription exists.
  useEffect(() => {
    if (loaded && !visiblePages.includes(activeTab)) navigate('/', { replace: true });
  }, [loaded, activeTab, hasSubs, hasTracking]);

  const addSubscription = async (record) => {
    await request('/subscriptions', { method: 'POST', body: JSON.stringify(record) });
    setNotice('Subscription saved.'); setModal(false); await refresh();
  };
  const addUsage = async (record) => {
    await request('/usage', { method: 'POST', body: JSON.stringify(record) });
    setNotice('Usage entry saved.'); setUsageModal(false); await refresh();
  };

  // Auto cancel opens the provider's page straight away. The window is opened first so the browser does not block it.
  const autoCancel = async (sub) => {
    if (sub.provider === 'razorpay' && !window.confirm('Cancel this Razorpay subscription immediately? No refund is issued.')) return;
    const win = window.open('about:blank', '_blank');
    try {
      const result = await request(`/subscriptions/${sub.id}/cancel`, { method: 'POST', body: JSON.stringify({ confirmed: sub.provider === 'razorpay' }) });
      if (result.status === 'redirect_required') {
        if (win) win.location.href = result.cancelUrl; else window.open(result.cancelUrl, '_blank', 'noopener,noreferrer');
        setSelected({ sub, opened: true });
        return;
      }
      win?.close();
      setNotice(result.notice || 'Subscription status updated.'); await refresh();
    } catch (e) {
      win?.close();
      setNotice(e.message);
    }
  };
  const confirmCanceled = async () => {
    try {
      const result = await request(`/subscriptions/${selected.sub.id}/confirm-canceled`, { method: 'POST', body: JSON.stringify({ confirmed: true }) });
      setNotice(result.notice); setSelected(null); await refresh();
    } catch (e) { setNotice(e.message); }
  };
  const openNotifications = async () => {
    setNotificationModal(true); setNotificationBusy(true); setNotificationError('');
    try { const result = await request('/notifications/preview'); setNotificationItems(result.items || []); }
    catch (e) { setNotificationError(e.message); }
    finally { setNotificationBusy(false); }
  };
  const logout = async () => {
    try { await request('/api/auth/logout', { method: 'POST', body: '{}' }); } catch {}
    setUser(null); setSubs([]); setAnalytics(emptyAnalytics); setLoaded(false); navigate('/');
  };

  const initials = user?.name?.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || 'U';
  if (authChecking) return <div className="auth-loading"><span className="brand-mark">S</span><p>Checking your session…</p></div>;
  if (!user || ['/reset-password', '/verify-email'].includes(location.pathname)) return <AuthScreen onAuthenticated={setUser} />;

  const titles = {
    Home: '', Subscriptions: 'Review every recurring service, renewal date and cancellation.',
    Analytics: 'Understand what your subscriptions cost and how much you use them.',
    'Browser tracking': 'Choose which services are measured in your browser.',
    Settings: 'Preferences and connections.'
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">S</span><span>Subscription Hub</span></div>
      <nav>{visiblePages.map((name) => <button key={name} className={`nav-item ${activeTab === name ? 'active' : ''}`} onClick={() => navigate(PAGES[name].path)}>
        <span>{{ Home: '◫', Subscriptions: '↻', Analytics: '▥', 'Browser tracking': '◎', Settings: '◉' }[name]}</span>{name}
      </button>)}</nav>
      <div className="sidebar-bottom"><div className="profile"><div className="avatar">{initials}</div><div className="profile-name"><b>{user.name}</b><small>{user.emailVerified ? 'Email verified' : 'Email not verified'}</small></div><button className="logout-button" onClick={logout}>Sign out</button></div></div>
    </aside>
    <main className="main">
      <header className="topbar">
        <div className="crumb">Workspace <span>/</span> <b>{activeTab}</b></div>
        <div className="top-actions">
          {updatedAt && live && <span className="live-stamp">Updated {updatedAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>}
          <span className={`api-status ${live ? 'connected' : ''}`}><i /> {live ? 'Connected' : 'Offline'}</span>
          {hasSubs && <button className="icon-button" aria-label="Renewal reminders" title="Renewal reminders (preview)" onClick={openNotifications}>♧</button>}
        </div>
      </header>
      <div className="content">
        {notice && <div className="toast"><span>✓</span>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss">×</button></div>}
        {activeTab !== 'Home' && <section className="welcome-row">
          <div><h1>{activeTab}</h1><p className="muted">{titles[activeTab]}</p></div>
          <div className="welcome-actions"><button className="primary" onClick={() => setModal(true)}>＋ Add subscription</button></div>
        </section>}

        {activeTab === 'Home' && <HomePage subs={subs} analytics={analytics} activeSubs={activeSubs} user={user} onAdd={() => setModal(true)} onExplore={(path) => navigate(path)} />}
        {activeTab === 'Subscriptions' && <SubscriptionsPage subs={subs} onAutoCancel={autoCancel} onAdd={() => setModal(true)} onImported={refresh} />}
        {activeTab === 'Analytics' && hasSubs && <AnalyticsPage analytics={analytics} subscriptions={activeSubs} onLogUsage={() => setUsageModal(true)} onChanged={refresh} />}
        {activeTab === 'Browser tracking' && hasTracking && <BrowserTrackingPage />}
        {activeTab === 'Settings' && hasSubs && <SettingsPage />}
        <footer className="footer-note">Subscription Hub · India · Amounts in INR</footer>
      </div>
    </main>

    {modal && <SubscriptionForm onClose={() => setModal(false)} onSave={addSubscription} />}
    {usageModal && <UsageForm subscriptions={activeSubs} onClose={() => setUsageModal(false)} onSave={addUsage} />}
    {selected && <div className="overlay"><div className="modal confirm-modal">
      <button className="modal-close" onClick={() => setSelected(null)} aria-label="Close">×</button>
      <div className="eyebrow">CANCELLATION</div>
      <h2>Did the provider confirm?</h2>
      <p>The provider's page opened in a new tab. Once it confirms the cancellation there, this subscription will be removed from your list.</p>
      <div className="modal-actions"><button className="secondary" onClick={() => setSelected(null)}>Not yet</button><button className="primary" onClick={confirmCanceled}>Provider confirmed · remove</button></div>
    </div></div>}
    {notificationModal && <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && setNotificationModal(false)}><div className="modal confirm-modal">
      <button className="modal-close" onClick={() => setNotificationModal(false)} aria-label="Close">×</button>
      <div className="eyebrow">RENEWAL REMINDERS</div>
      <h2>Due in the next three days</h2>
      {notificationBusy ? <div className="empty">Loading…</div> : notificationError ? <div className="auth-error" role="alert">{notificationError}</div> : notificationItems.length ? notificationItems.map((item) => <div className="review-item" key={item.id}><div><b>{item.name}</b><p>{new Date(item.renewalDate).toLocaleDateString('en-IN')} · {money(item.monthlyCost)}</p></div><strong>Review</strong></div>) : <div className="empty">Nothing renews in the next three days.</div>}
    </div></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><BrowserRouter><App /></BrowserRouter></React.StrictMode>);
