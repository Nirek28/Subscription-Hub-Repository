@echo off
title Subscription Hub
cd /d "%~dp0"
node scripts\launch.mjs
if errorlevel 1 (
  echo.
  echo Subscription Hub could not start. If Node.js is missing, install the LTS version from https://nodejs.org
  pause
)
