#!/bin/sh
# macOS: double-click this file (first time: right-click > Open, or run: chmod +x start.command)
cd "$(dirname "$0")" || exit 1
node scripts/launch.mjs
