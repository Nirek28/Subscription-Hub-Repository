// One-step launcher: prepares settings, installs packages on first run, builds the website
// and starts the server at http://localhost:4000. No VS Code or terminal knowledge needed.
import { existsSync, readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import http from 'node:http';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PORT = 4000;
const ADDRESS = `http://localhost:${PORT}`;
const isWindows = process.platform === 'win32';
const npm = isWindows ? 'npm.cmd' : 'npm';
const envPath = resolve(root, '.env');

function step(message) {
  console.log(`\n▸ ${message}`);
}

function fail(message) {
  console.error(`\n✖ ${message}`);
  console.error('Press Enter to close this window.');
  process.stdin.resume();
  process.stdin.once('data', () => process.exit(1));
}

function run(command, args) {
  return spawnSync(command, args, { cwd: root, stdio: 'inherit', shell: isWindows });
}

const major = Number(process.versions.node.split('.')[0]);
if (major < 18) {
  fail('Node.js 18 or newer is required. Install the LTS version from https://nodejs.org and try again.');
}

console.log('Subscription Hub — starting up');

step('Checking settings');
if (!existsSync(envPath)) {
  copyFileSync(resolve(root, '.env.example'), envPath);
  console.log('Created .env from .env.example.');
}
let envText = readFileSync(envPath, 'utf8');
if (/^SESSION_SECRET=\s*$/m.test(envText)) {
  envText = envText.replace(/^SESSION_SECRET=\s*$/m, `SESSION_SECRET=${randomBytes(32).toString('hex')}`);
  writeFileSync(envPath, envText);
  console.log('Generated a private SESSION_SECRET.');
}

if (!existsSync(resolve(root, 'node_modules'))) {
  step('Installing packages (first run only, a few minutes)');
  if (run(npm, ['install']).status !== 0) fail('Package installation failed. Check your internet connection and run the launcher again.');
}

step('Building the website');
if (run(npm, ['run', 'build']).status !== 0) fail('The website could not be built. Send the error above to your developer.');

step(`Starting the server on ${ADDRESS}`);
const api = spawn(process.execPath, ['apps/api/src/index.js'], {
  cwd: root,
  stdio: 'inherit',
  // Same address for website and API, so sign-in and extension pairing work without extra setup.
  env: { ...process.env, PORT: String(PORT), WEB_ORIGIN: ADDRESS }
});

function openBrowser() {
  const command = process.platform === 'darwin' ? 'open' : isWindows ? 'cmd' : 'xdg-open';
  const args = isWindows ? ['/c', 'start', '""', ADDRESS] : [ADDRESS];
  try { spawn(command, args, { stdio: 'ignore', detached: true, shell: false }).unref(); } catch { /* open the address manually */ }
}

function waitForServer(attempts = 60) {
  http.get(`${ADDRESS}/api/health`, res => {
    res.resume();
    if (res.statusCode === 200) {
      console.log(`\n✔ Subscription Hub is running: ${ADDRESS}`);
      console.log('  Keep this window open while you use the app. Press Ctrl+C here to stop it.\n');
      openBrowser();
    } else if (attempts > 0) setTimeout(() => waitForServer(attempts - 1), 1000);
  }).on('error', () => {
    if (attempts > 0) setTimeout(() => waitForServer(attempts - 1), 1000);
  });
}
waitForServer();

process.on('SIGINT', () => api.kill('SIGINT'));
process.on('SIGTERM', () => api.kill('SIGTERM'));
api.on('exit', code => {
  if (code) fail(`The server stopped with code ${code}.`);
  process.exit(code || 0);
});
